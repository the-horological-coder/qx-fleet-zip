export { default } from "./DataError";
