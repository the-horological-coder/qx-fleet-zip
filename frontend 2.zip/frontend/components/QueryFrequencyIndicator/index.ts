export { default } from "./QueryFrequencyIndicator";
