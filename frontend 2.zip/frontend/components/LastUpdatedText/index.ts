export { default } from "./LastUpdatedText";
