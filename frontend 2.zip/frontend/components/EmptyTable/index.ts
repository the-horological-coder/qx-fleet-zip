export { default } from "./EmptyTable";
