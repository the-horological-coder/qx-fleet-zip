export { default } from "./TabsWrapper";
