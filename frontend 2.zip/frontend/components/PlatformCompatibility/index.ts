export { default } from "./PlatformCompatibility";
