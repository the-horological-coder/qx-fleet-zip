export { default } from "./PremiumFeatureIconWithTooltip";
