export { default } from "./Spinner";
