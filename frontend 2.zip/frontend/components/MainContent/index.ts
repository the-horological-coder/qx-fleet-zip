export { default } from "./MainContent";
