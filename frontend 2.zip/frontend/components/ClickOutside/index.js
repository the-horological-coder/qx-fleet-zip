export { default } from "./ClickOutside";
