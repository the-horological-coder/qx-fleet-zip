export { default } from "./SSOError";
