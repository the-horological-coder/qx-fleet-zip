export { default } from "./AppleBMTermsMessage";
