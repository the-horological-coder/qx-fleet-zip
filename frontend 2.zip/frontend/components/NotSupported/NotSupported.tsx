import React from "react";

export const NotSupported = (
  <span className="not-supported">Not supported</span>
);
export default NotSupported;
