export { default } from "./InfoBanner";
