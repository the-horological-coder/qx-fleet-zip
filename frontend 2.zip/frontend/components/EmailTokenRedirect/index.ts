export { default } from "./EmailTokenRedirect";
