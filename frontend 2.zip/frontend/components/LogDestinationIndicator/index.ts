export { default } from "./LogDestinationIndicator";
