// __mocks__/fileMock.js

module.exports = "test-file-stub";
