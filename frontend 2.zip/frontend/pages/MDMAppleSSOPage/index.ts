export { default } from "./MDMAppleSSOPage";
