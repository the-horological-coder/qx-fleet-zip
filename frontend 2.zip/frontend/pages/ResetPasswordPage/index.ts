export { default } from "./ResetPasswordPage";
