export { default } from "./ConfirmSSOInvitePage";
