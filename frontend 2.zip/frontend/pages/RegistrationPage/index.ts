export { default } from "./RegistrationPage";
