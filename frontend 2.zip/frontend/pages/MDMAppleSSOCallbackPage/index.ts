export { default } from "./MDMAppleSSOCallbackPage";
