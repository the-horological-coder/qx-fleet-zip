export { default } from "./ConfirmInvitePage";
