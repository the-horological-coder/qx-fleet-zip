export { default } from "./LogoutPage";
