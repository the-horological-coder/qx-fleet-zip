export { default } from "./LabelPage";
