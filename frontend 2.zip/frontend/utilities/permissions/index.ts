export { default } from "./permissions";
