export { default } from "./GatedLayout";
