import PropTypes, { number } from "prop-types";

import scheduledQueryStatsInterface, {
  IScheduledQueryStats,
} from "./scheduled_query_stats";

export default PropTypes.shape({
  scheduled_query_name: PropTypes.string,
  scheduled_query_id: PropTypes.number,
  query_name: PropTypes.string,
  description: PropTypes.string,
  pack_name: PropTypes.string,
  pack_id: PropTypes.number,
  average_memory: number,
  denylisted: PropTypes.bool,
  executions: PropTypes.number,
  interval: PropTypes.number,
  last_executed: PropTypes.string,
  output_size: PropTypes.number,
  system_time: PropTypes.number,
  user_time: PropTypes.number,
  wall_time: PropTypes.number,
  stats: scheduledQueryStatsInterface,
});

export interface IQueryStats {
  scheduled_query_name: string;
  scheduled_query_id: number;
  query_name: string;
  description: string;
  pack_name: string;
  pack_id: number;
  average_memory: number;
  denylisted: boolean;
  executions: number;
  interval: number;
  last_executed: string;
  output_size?: number;
  system_time: number;
  user_time: number;
  wall_time?: number;
  stats?: IScheduledQueryStats;
}
