import URL_PREFIX from "router/url_prefix";

// Sets the path used to load assets
__webpack_public_path__ = `${URL_PREFIX}/assets/`; // eslint-disable-line camelcase, no-undef
